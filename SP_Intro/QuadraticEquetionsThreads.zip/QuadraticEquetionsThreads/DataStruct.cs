﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace QuadraticEquationsThreads
{
    public struct DataStruct
    {
        public int num { get; set; }
        public List<int> a { get; set; }
        public List<int> b { get; set; }
        public List<int> c { get; set; }
    }
}
