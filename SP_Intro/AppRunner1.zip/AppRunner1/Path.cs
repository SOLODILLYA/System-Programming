﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRunner1
{
    internal class Path
    {
        public string PathString { get; set; }
        public string Name { get; set; }
    }
}
